package Java2;

public class Person {
    private String name;
    private String schoolNAme = "bingham University";
    private String password;

    String getName(){
        return name;
    }
}
