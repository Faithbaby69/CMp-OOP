package Java2;

public class Variables {
    public static void main(String[] args) {
        String name = "Daniel";
        boolean alive = true;
        if (alive == true){
            System.out.println(name);
        }
        else{
            System.out.println("Nothing to print");
        }
        
    }
    
}
